﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ServiceSystem.Controllers
{
    public class WMData
    {
        public int LMI_MODE { get; set; }
        public double LMI_PAYMENT_AMOUNT { get; set; }
        public string LMI_PAYEE_PURSE { get; set; }
        public int LMI_PAYMENT_NO { get; set; }
        public decimal LMI_PAYER_WM { get; set; }
        public string LMI_PAYER_PURSE { get; set; }
        public string LMI_PAYER_COUNTRYID { get; set; }
        public string LMI_PAYER_IP { get; set; }
        public int LMI_SYS_INVS_NO { get; set; }
        public int LMI_SYS_TRANS_NO { get; set; }
        public DateTime LMI_SYS_TRANS_DATE { get; set; }
        public string LMI_HASH { get; set; }
        public string LMI_HASH2 { get; set; }
        public string LMI_PAYMENT_DESC { get; set; }
        public string LMI_LANG { get; set;}
        public string LMI_DBLCHK { get; set; }
    }
    public class WebmoneyController : ApiController
    {
        [ActionName("PostTransactionData")]
        public HttpResponseMessage Post([FromBody] WMData wmData)
        {
            using (SqlConnection connection = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings["DBCS"].ConnectionString))
            {
                string cmdString = "INSERT INTO WMPaymentLog VALUES(@AppId, @TransactionTime);";

                SqlCommand cmd = new SqlCommand(cmdString, connection);

                cmd.Parameters.AddWithValue("@AppId", wmData.LMI_PAYMENT_NO);
                cmd.Parameters.AddWithValue("@TransactionTime", wmData.LMI_SYS_TRANS_DATE);

                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch
                {
                }
            }

                return Request.CreateResponse(HttpStatusCode.OK, "OK");
        }
    }
}
